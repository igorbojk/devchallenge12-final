# dev-challenge12-final

# Builded application in 'dist' folder

## 'npm i' for install dependencies

## 'npm run serve' for run in dev mode

## 'npm run build' for building app
